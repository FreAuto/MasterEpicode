-- Esame Finale Modulo SQL
-- ============================================
--  ToysGroup - Database completo
--  DBMS: MySQL
-- ============================================
--
--  INDICE DEI TASK
--  - TASK 2 - Creazione delle tabelle
--  - TASK 3 - Popolamento delle tabelle
--  - TASK 4 - Query di analisi e viste
--
-- ============================================


-- ============================================
--  INIZIO TASK 2 - Creazione delle tabelle
-- ============================================

-- --------------------------------------------
--  Tabella CATEGORY
-- --------------------------------------------
CREATE TABLE Category (
    CategoryID   INT          NOT NULL,
    CategoryName VARCHAR(50)  NOT NULL,
    CONSTRAINT PK_Category PRIMARY KEY (CategoryID)
);

-- --------------------------------------------
--  Tabella PRODUCT
--  Rappresenta il singolo articolo venduto.

-- --------------------------------------------
CREATE TABLE Product (
    ProductID   INT            NOT NULL,
    ProductName VARCHAR(100)   NOT NULL,
    Price       DECIMAL(10,2)  NOT NULL,
    CategoryID  INT            NOT NULL,
    CONSTRAINT PK_Product          PRIMARY KEY (ProductID),
    CONSTRAINT FK_Product_Category FOREIGN KEY (CategoryID)
        REFERENCES Category(CategoryID)
);

-- --------------------------------------------
--  Tabella REGION
--  Ogni regione raggruppa più paesi.
-- --------------------------------------------
CREATE TABLE Region (
    RegionID   INT         NOT NULL,
    RegionName VARCHAR(50) NOT NULL,
    CONSTRAINT PK_Region PRIMARY KEY (RegionID)
);

-- --------------------------------------------
--  Tabella COUNTRY
--  Rappresenta il singolo paese di vendita.
--  Ogni paese appartiene a una sola regione.
-- --------------------------------------------
CREATE TABLE Country (
    CountryID   INT         NOT NULL,
    CountryName VARCHAR(50) NOT NULL,
    RegionID    INT         NOT NULL,
    CONSTRAINT PK_Country        PRIMARY KEY (CountryID),
    CONSTRAINT FK_Country_Region FOREIGN KEY (RegionID)
        REFERENCES Region(RegionID)
);

-- --------------------------------------------
--  Tabella SALES
--  Tabella dei fatti: registra ogni singola
--  transazione di vendita.
--  Collega un prodotto a un paese.
--  UnitPrice salva il prezzo al momento della
--  vendita (può differire dal listino attuale).
-- --------------------------------------------
CREATE TABLE Sales (
    SaleID    INT            NOT NULL,
    SaleDate  DATE           NOT NULL,
    Quantity  INT            NOT NULL,
    UnitPrice DECIMAL(10,2)  NOT NULL,
    ProductID INT            NOT NULL,
    CountryID INT            NOT NULL,
    CONSTRAINT PK_Sales         PRIMARY KEY (SaleID),
    CONSTRAINT FK_Sales_Product FOREIGN KEY (ProductID)
        REFERENCES Product(ProductID),
    CONSTRAINT FK_Sales_Country FOREIGN KEY (CountryID)
        REFERENCES Country(CountryID)
);

-- ============================================
--  FINE TASK 2
-- ============================================


-- ============================================
--  INIZIO TASK 3 - Popolamento delle tabelle
--  Ordine corretto:
--    1. Category
--    2. Product     (dipende da Category)
--    3. Region
--    4. Country     (dipende da Region)
--    5. Sales       (dipende da Product e Country)
-- ============================================


-- --------------------------------------------
--  STEP 1 - Inserimento categorie prodotto
-- --------------------------------------------
INSERT INTO Category (CategoryID, CategoryName) VALUES (1, 'Bikes');
INSERT INTO Category (CategoryID, CategoryName) VALUES (2, 'Clothing');
INSERT INTO Category (CategoryID, CategoryName) VALUES (3, 'Accessories');


-- --------------------------------------------
--  STEP 2 - Inserimento prodotti
--  Ogni prodotto è associato a una categoria
--  esistente tramite CategoryID.
-- --------------------------------------------
INSERT INTO Product (ProductID, ProductName, Price, CategoryID) VALUES (1, 'Bikes-100',     299.99, 1);
INSERT INTO Product (ProductID, ProductName, Price, CategoryID) VALUES (2, 'Bikes-200',     499.99, 1);
INSERT INTO Product (ProductID, ProductName, Price, CategoryID) VALUES (3, 'Bike Gloves M',  19.99, 2);
INSERT INTO Product (ProductID, ProductName, Price, CategoryID) VALUES (4, 'Bike Gloves L',  19.99, 2);
INSERT INTO Product (ProductID, ProductName, Price, CategoryID) VALUES (5, 'Helmet Pro',     89.99, 3);


-- --------------------------------------------
--  STEP 3 - Inserimento regioni di vendita
-- --------------------------------------------
INSERT INTO Region (RegionID, RegionName) VALUES (1, 'WestEurope');
INSERT INTO Region (RegionID, RegionName) VALUES (2, 'SouthEurope');
INSERT INTO Region (RegionID, RegionName) VALUES (3, 'NorthAmerica');


-- --------------------------------------------
--  STEP 4 - Inserimento paesi
--  Ogni paese è associato a una regione
--  esistente tramite RegionID.
-- --------------------------------------------
INSERT INTO Country (CountryID, CountryName, RegionID) VALUES (1, 'France',        1);
INSERT INTO Country (CountryID, CountryName, RegionID) VALUES (2, 'Germany',       1);
INSERT INTO Country (CountryID, CountryName, RegionID) VALUES (3, 'Italy',         2);
INSERT INTO Country (CountryID, CountryName, RegionID) VALUES (4, 'Greece',        2);
INSERT INTO Country (CountryID, CountryName, RegionID) VALUES (5, 'United States', 3);


-- --------------------------------------------
--  STEP 5 - Inserimento transazioni di vendita
--  Ogni record rappresenta una singola vendita:
--  quale prodotto, in quale paese, quando,
--  quante unità e a quale prezzo unitario.
-- --------------------------------------------
INSERT INTO Sales (SaleID, SaleDate,     Quantity, UnitPrice, ProductID, CountryID) VALUES (1,  '2024-01-10',  3, 299.99, 1, 1);
INSERT INTO Sales (SaleID, SaleDate,     Quantity, UnitPrice, ProductID, CountryID) VALUES (2,  '2024-01-15',  1, 499.99, 2, 2);
INSERT INTO Sales (SaleID, SaleDate,     Quantity, UnitPrice, ProductID, CountryID) VALUES (3,  '2024-02-03',  5,  19.99, 3, 3);
INSERT INTO Sales (SaleID, SaleDate,     Quantity, UnitPrice, ProductID, CountryID) VALUES (4,  '2024-02-20',  2,  19.99, 4, 4);
INSERT INTO Sales (SaleID, SaleDate,     Quantity, UnitPrice, ProductID, CountryID) VALUES (5,  '2024-03-05', 10,  89.99, 5, 5);
INSERT INTO Sales (SaleID, SaleDate,     Quantity, UnitPrice, ProductID, CountryID) VALUES (6,  '2024-03-18',  4, 299.99, 1, 3);
INSERT INTO Sales (SaleID, SaleDate,     Quantity, UnitPrice, ProductID, CountryID) VALUES (7,  '2024-04-01',  2, 499.99, 2, 5);
INSERT INTO Sales (SaleID, SaleDate,     Quantity, UnitPrice, ProductID, CountryID) VALUES (8,  '2024-04-22',  6,  19.99, 3, 1);
INSERT INTO Sales (SaleID, SaleDate,     Quantity, UnitPrice, ProductID, CountryID) VALUES (9,  '2024-05-09',  1,  89.99, 5, 2);
INSERT INTO Sales (SaleID, SaleDate,     Quantity, UnitPrice, ProductID, CountryID) VALUES (10, '2024-05-30',  3,  19.99, 4, 5);

-- ============================================
--  FINE TASK 3
-- ============================================


-- ============================================
--  INIZIO TASK 4 - Query di analisi e viste

--  QUERY:
--  QUERY 1: Verifica univocità delle PK
--  QUERY 2: Elenco transazioni con flag >180gg
--  QUERY 3: Prodotti con quantità > media ultimo anno
--  QUERY 4: Fatturato per prodotto per anno
--  QUERY 5: Fatturato per stato per anno
--  QUERY 6: Categoria più richiesta dal mercato
--  QUERY 7: Prodotti invenduti (due approcci)
--  QUERY 8: Vista denormalizzata sui prodotti
--  QUERY 9: Vista sulle informazioni geografiche
-- ============================================


-- --------------------------------------------
--  QUERY 1 - Verifica univocità delle chiavi primarie
--
--  Per ogni tabella, si raggruppano i record
--  per  e si contano le occorrenze.
--  Se è meno di 1 il valore è duplicato e
--  l'univocità è violata. Un result set vuoto
--  conferma che tutte le Chiavi sono univoche.
-- --------------------------------------------

-- Verifica PK tabella Category
SELECT
    CategoryID,
    COUNT(*) AS Occorrenze
FROM Category
GROUP BY CategoryID
HAVING COUNT(*) > 1;

-- Verifica PK tabella Product
SELECT
    ProductID,
    COUNT(*) AS Occorrenze
FROM Product
GROUP BY ProductID
HAVING COUNT(*) > 1;

-- Verifica PK tabella Region
SELECT
    RegionID,
    COUNT(*) AS Occorrenze
FROM Region
GROUP BY RegionID
HAVING COUNT(*) > 1;

-- Verifica PK tabella Country
SELECT
    CountryID,
    COUNT(*) AS Occorrenze
FROM Country
GROUP BY CountryID
HAVING COUNT(*) > 1;

-- Verifica PK tabella Sales
SELECT
    SaleID,
    COUNT(*) AS Occorrenze
FROM Sales
GROUP BY SaleID
HAVING COUNT(*) > 1;


-- --------------------------------------------
--  QUERY 2 - Elenco transazioni con flag 180 giorni
--
--  Faccio JOIN su tutte le tabelle per
--  ottenere le informazioni descrittive di ogni
--  vendita. Il campo booleano Over180Days viene
--  calcolato confrontando la data di vendita
--  con la data odierna tramite DATEDIFF:
--    - 1 (True)  se sono passati più di 180 giorni
--    - 0 (False) se sono passati 180 giorni o meno
-- --------------------------------------------
SELECT
    s.SaleID                                              AS CodiceDocumento,
    s.SaleDate                                            AS DataVendita,
    p.ProductName                                         AS NomeProdotto,
    c.CategoryName                                        AS CategoriaProdotto,
    co.CountryName                                        AS NomeStato,
    r.RegionName                                          AS NomeRegione,
    CASE
        WHEN DATEDIFF(CURDATE(), s.SaleDate) > 180
        THEN True
        ELSE False
    END                                                   AS Over180Days
FROM       Sales    s
INNER JOIN Product  p  ON s.ProductID  = p.ProductID
INNER JOIN Category c  ON p.CategoryID = c.CategoryID
INNER JOIN Country  co ON s.CountryID  = co.CountryID
INNER JOIN Region   r  ON co.RegionID  = r.RegionID
ORDER BY s.SaleDate;


-- --------------------------------------------
--  QUERY 3 - Prodotti con quantità totale venduta
--            superiore alla media dell'ultimo anno
--
--  L'anno di riferimento ("ultimo anno censito")
--  viene ricavato dinamicamente come MAX(YEAR(SaleDate)).
--  La media delle vendite di quell'anno è anch'essa
--  calcolata tramite subquery.
--  Nel result set compaiono solo ProductID e
--  il totale delle unità vendute.
-- --------------------------------------------
SELECT
    s.ProductID,
    SUM(s.Quantity) AS TotaleVenduto
FROM Sales s
WHERE YEAR(s.SaleDate) = (
    SELECT MAX(YEAR(SaleDate))
    FROM Sales
)
GROUP BY s.ProductID
HAVING SUM(s.Quantity) > (
    SELECT AVG(QuantitaPerProdotto)
    FROM (
        SELECT SUM(Quantity) AS QuantitaPerProdotto
        FROM Sales
        WHERE YEAR(SaleDate) = (
            SELECT MAX(YEAR(SaleDate))
            FROM Sales
        )
        GROUP BY ProductID
    ) AS MediaCalcolata
)
ORDER BY TotaleVenduto DESC;


-- --------------------------------------------
--  QUERY 4 - Fatturato per prodotto per anno
--
--  Vengono considerati solo i prodotti che
--  hanno almeno una vendita.
--  Il fatturato è calcolato come somma di
--  Quantity * UnitPrice per ogni combinazione
--  prodotto/anno.
-- --------------------------------------------
SELECT
    p.ProductID,
    p.ProductName,
    YEAR(s.SaleDate)              AS Anno,
    SUM(s.Quantity * s.UnitPrice) AS FatturatoTotale
FROM       Sales   s
INNER JOIN Product p ON s.ProductID = p.ProductID
GROUP BY
    p.ProductID,
	Anno
ORDER BY
    p.ProductID,
    Anno;


-- --------------------------------------------
--  QUERY 5 - Fatturato totale per stato per anno
--
--  Calcola il fatturato aggregato per paese
--  e per anno.
-- --------------------------------------------
SELECT
    co.CountryName,
    YEAR(s.SaleDate)              AS Anno,
    SUM(s.Quantity * s.UnitPrice) AS FatturatoTotale
FROM       Sales   s
INNER JOIN Country co ON s.CountryID = co.CountryID
GROUP BY
    co.CountryName,
	Anno
ORDER BY
    Anno            ASC,
    FatturatoTotale DESC;


-- --------------------------------------------
--  QUERY 6 - Categoria più richiesta dal mercato
--
--  "Più richiesta" è interpretata come la
--  categoria con il maggior numero di unità
--  totali vendute (somma delle quantità).
-- --------------------------------------------
SELECT
    c.CategoryID,
    c.CategoryName,
    SUM(s.Quantity) AS TotaleUnitaVendute
FROM       Sales    s
INNER JOIN Product  p ON s.ProductID  = p.ProductID
INNER JOIN Category c ON p.CategoryID = c.CategoryID
GROUP BY
    c.CategoryID,
    c.CategoryName
ORDER BY TotaleUnitaVendute DESC
LIMIT 1;


-- --------------------------------------------
--  QUERY 7 - Prodotti invenduti
--
--  Un prodotto si definisce "invenduto" quando
--  non è presente nella tabella Sales. 
--
--  APPROCCIO A - LEFT JOIN + IS NULL
--  Si esegue un LEFT JOIN tra Product e Sales:
--  i prodotti senza corrispondenze avranno NULL
--  nel campo SaleID lato Sales. Il filtro WHERE
--  isola questi record.
-- --------------------------------------------

-- Approccio A: LEFT JOIN con filtro IS NULL
SELECT
    p.ProductID,
    p.ProductName
FROM      Product p
LEFT JOIN Sales   s ON p.ProductID = s.ProductID
WHERE s.SaleID IS NULL;

-- --------------------------------------------
--  APPROCCIO B - NOT EXISTS
--  Per ogni prodotto si verifica l'assenza di
--  qualsiasi riga in Sales che lo referenzi.
--  NOT EXISTS restituisce TRUE (e quindi include
--  il prodotto) quando la subquery è vuota.
-- --------------------------------------------

-- Approccio B: NOT EXISTS con subquery correlata
SELECT
    p.ProductID,
    p.ProductName
FROM Product p
WHERE NOT EXISTS (
    SELECT 1
    FROM Sales s
    WHERE s.ProductID = p.ProductID
);

-- --------------------------------------------
--  QUERY 8 - Vista denormalizzata sui prodotti
--
--  La vista espone le informazioni principali
--  unendo Product e Category. Evita ai consumer 
-- della vista di dover eseguire ogni volta il JOIN.
-- --------------------------------------------
CREATE VIEW VWProductDetails AS 
SELECT
		p.ProductID,
		p.ProductName,
		c.CategoryName
FROM       	
		Product  p
INNER JOIN
		Category c ON p.CategoryID = c.CategoryID;

-- --------------------------------------------
--  QUERY 9 - Vista sulle informazioni geografiche
--
--  La vista espone la gerarchia geografica
--  completa (paese + regione) in un unico livello,
--  semplificando le query che necessitano di
--  filtrare o raggruppare per area geografica.
-- --------------------------------------------
CREATE VIEW vw_GeographyDetails AS
SELECT
    co.CountryID,
    co.CountryName,
    r.RegionID,
    r.RegionName
FROM       Country co
INNER JOIN Region  r ON co.RegionID = r.RegionID;

-- ============================================
--  FINE TASK 4
-- ============================================